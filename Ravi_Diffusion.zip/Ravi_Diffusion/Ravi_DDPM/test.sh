#!/bin/bash
#SBATCH --job-name=ravi_prr # Job name
#SBATCH --partition=large #Partition Name (phd,large,dgx) to know more use cli--->sinfo
#SBATCH --nodes=1 # Run all processes on a single node
#SBATCH --ntasks=1 # Run a single task
#SBATCH --cpus-per-task=1 # Number of CPU cores per task
#SBATCH --output=out-%j.log # Standard output and error log
#SBATCH --gres=gpu:1 # Include gpu for the task (only for GPU jobs)  





#-------->  To Display nvidia Conditions

nvidia-smi



#-------->  LOADING_MODULES  YOU CAN SEE ALL MODULES AS USE CLI ------> "module avail"   

# module load python/3.10
#module load conda/conda



#------->  TO ATTACH ENVIRONMENT           IN IITj_HPC (NO NEED FOR bashrc)  WHILE IN CLUSTER_DPU IT IS NEEDED)  so here it is # commented

s#ource ~/.bashrc


#------->  TO ACTIVATE DESIRED ENVIRONMENT/VIRTUAL_ENVIRONMENT  ie CONDA/PYTHON_VENV

#conda activate diffusion
#source /csehome/p23cs0006/venvs/ravi_env/bin/activate


#-------->  RUN YOUR SCRIPT   python/bash   ETC  
python infer.py




#-------->  FINALL CONDITION OF GPU
nvidia-smi




#-------->  SPECIAL COMMANDS
#sinfo
#squeue
#squeue -u p23cs0006

#srun --partition=phd --nodes=1 --ntasks=1 --gres=gpu:1 --pty /bin/bash
#srun --jobid 13868  --pty watch -n 0.5 nvidia-smi

