﻿

## Training

### Start Training from Scratch

~~~
python train.py
~~~

## Inference

### Start Inference

~~~
python infer.py 
~~~


