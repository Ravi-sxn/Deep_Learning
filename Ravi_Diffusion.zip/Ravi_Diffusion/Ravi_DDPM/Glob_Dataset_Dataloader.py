""" This code is for Creating Dataset and Dataloader such that FOLDER-->FOLDER--->-----Image_Folder(that contain all images)  Using GLOB Function"""




import torch
from torch.utils.data import Dataset,DataLoader
from PIL import Image
from  torchvision import transforms
import glob
from tqdm.auto import tqdm
import os


class BaseDataset(Dataset):
    def __init__(self, path:str = "" ,transform:transforms.Compose = None, image_Resize:int = ""):
        self.path = path
        self.image_list = glob.glob(f"{path}/*/*.jpg")
        print(f"[LOG] total images found: {len(self.image_list)}")
       
       
       
        if transform == None:
            self.transform = transforms.Compose(
                [
                    transforms.Resize(size=(image_Resize,image_Resize)),
                    transforms.ToTensor(),
                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
                ]
            )
        else:
            self.transform = transform


    def __getitem__(self, index):
        image_path = self.image_list[index]
        image = Image.open(image_path)
        image = self.transform(image)
        img=image
        img = (img - 127.5) / 127.5
        # check for 1-chanel img if found then convert it into RGB
        if image.shape[0] == 1:
            image= torch.stack([image.squeeze(),image.squeeze(),image.squeeze()])
            # print(image.shape)

        return image


    def __len__(self):
        return len(self.image_list)







# Testing Dataloader 

if __name__ == "__main__":
    print("*"*100)
    my_dataset
    print(f"[INFO] length_my_dataset: {len(my_dataset)}")

    
    my_dataloader
    print("*"*100)
    for i in tqdm(my_dataloader,total=len(my_dataloader)):
        pass

    print("*"*100)


"""# For Iterate it Full Dataloader (Optional)

for images in my_dataloader:
    print(images.shape)  # Example: torch.Size([32, 3, 128, 128])"""
      
